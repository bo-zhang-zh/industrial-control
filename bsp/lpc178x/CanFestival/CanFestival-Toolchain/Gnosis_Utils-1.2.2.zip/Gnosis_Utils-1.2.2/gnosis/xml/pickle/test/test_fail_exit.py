# used for sanity checking the test harness
# "fail" a test by using sys.exit(1)

import sys
sys.exit(1)
